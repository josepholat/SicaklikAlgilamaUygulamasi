package Uygulama;

import java.sql.Connection;

/**
 *
 * @author Ziroo
 */
public interface IVeritabaniBaglantisi {
    Connection baglan();
    void baglantiSonlandir();
}