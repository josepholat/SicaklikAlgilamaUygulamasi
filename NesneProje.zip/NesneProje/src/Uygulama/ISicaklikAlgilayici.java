package Uygulama;

/**
 *
 * @author Ziroo
 */
public interface ISicaklikAlgilayici {
    int sicaklikOku();
}
