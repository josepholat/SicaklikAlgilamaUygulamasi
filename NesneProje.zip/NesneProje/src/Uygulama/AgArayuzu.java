package Uygulama;

/**
 *
 * @author Ziroo
 */
public class AgArayuzu implements IAgArayuzu {

    private static IAgArayuzu instance;

    private AgArayuzu(){
        instance = null;
    }
    
    public static synchronized IAgArayuzu getInstance(){
        if(instance == null)
            instance = new AgArayuzu();
        return instance;
    }
    
    @Override
    public void sogutucuAc() {
        MerkeziIslem.getInstance().sogutucuAc();
    }

    @Override
    public void sogutucuKapat() {
        MerkeziIslem.getInstance().sogutucuKapat();
    }

    @Override
    public void sicaklikGoruntule() {
        MerkeziIslem.getInstance().sicaklikGoruntule();
    }
    
}
