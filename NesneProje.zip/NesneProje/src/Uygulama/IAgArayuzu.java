package Uygulama;

/**
 *
 * @author Ziroo
 */
public interface IAgArayuzu {
    public void sogutucuAc();
    public void sogutucuKapat();
    public void sicaklikGoruntule();
}
