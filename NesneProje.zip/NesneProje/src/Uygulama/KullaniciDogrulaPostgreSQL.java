package Uygulama;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ziroo
 */
public class KullaniciDogrulaPostgreSQL implements IKullaniciDogrula {
    private static IKullaniciDogrula instance;
    private IVeritabaniBaglantisi veritabanibaglantisi;

    private KullaniciDogrulaPostgreSQL(){
        veritabanibaglantisi = VeritabaniBaglantisiPostgreSQL.getInstance();
        instance = null;
    }
    public static synchronized IKullaniciDogrula getInstance(){
        if(instance==null)
            instance=new KullaniciDogrulaPostgreSQL();
        return instance;
    }
    @Override
    public Kullanici kullaniciyiGetir(String kullaniciadi,String sifre) {
        
        ArrayList<Kullanici> kullanicilar = new ArrayList<Kullanici>();
        
        Connection conn = veritabanibaglantisi.baglan();
        Statement statement;
        
        try {
            statement = conn.createStatement();

            String sorgu = "SELECT * FROM \"Kullanicilar\"";
            ResultSet rs = statement.executeQuery(sorgu);
            conn.close();
            while(rs.next()){
                int KullaniciID = rs.getInt("kullaniciID");
                String Adi = rs.getString("ad");
                String Soyadi = rs.getString("soyad");
                String Mail = rs.getString("kullaniciAdi");
                String Sifre = rs.getString("kullaniciSifre");
                boolean yetkiliMi = rs.getBoolean("yetkiliMi");
                
                Kullanici kullanici = new Kullanici(Adi,Soyadi,Mail,Sifre,yetkiliMi);
                kullanici.setKullaniciID(KullaniciID);
                kullanicilar.add(kullanici);
        }
            VeritabaniBaglantisiPostgreSQL.getInstance().baglantiSonlandir();
            statement.close();

        } catch (SQLException ex) {
            Logger.getLogger(KullaniciDogrulaPostgreSQL.class.getName()).log(Level.SEVERE, null, ex);
        }

        for(Kullanici kullanici:kullanicilar){
            if(kullanici.getKullaniciAdi().equals(kullaniciadi)&&kullanici.getSifre().equals(sifre)){
                return kullanici;
            }              
        }
        return null;
    }
    
}