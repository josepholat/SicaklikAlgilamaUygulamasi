package Uygulama;

import java.util.Random;

/**
 *
 * @author Ziroo
 */
public class SicaklikAlgilayici implements ISicaklikAlgilayici {

    private static ISicaklikAlgilayici instance;

    private SicaklikAlgilayici(){
        instance = null;
    }
    
    public static synchronized ISicaklikAlgilayici getInstance(){
        if(instance==null)
            instance=new SicaklikAlgilayici();
        return instance;
    }
    
    @Override
    public int sicaklikOku() {
        Random rand = new Random();
         int sicaklik= -10 + rand.nextInt(50);
         return sicaklik;
    }
    
}
