package Uygulama;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Ziroo
 */
public class VeritabaniBaglantisiPostgreSQL implements IVeritabaniBaglantisi {
    private Connection conn = null;
    private static IVeritabaniBaglantisi instance;
    
    private VeritabaniBaglantisiPostgreSQL(){
        
    }
    public static synchronized IVeritabaniBaglantisi getInstance(){
        if(instance==null)
            instance = new VeritabaniBaglantisiPostgreSQL();
        return instance;
    } 
    @Override
    public Connection baglan() {
        
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/nesneodev",
                    "postgres", "admin");
            
            if (conn != null)
                System.out.println("Veritabanı baglantisi kuruldu!");
            else
                System.out.println("Veritabani baglantisi basarisiz!");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    @Override
    public void baglantiSonlandir() {
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(VeritabaniBaglantisiPostgreSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}