package Uygulama;

/**
 *
 * @author Ziroo
 */
public interface IMerkeziIslem {
    public void sogutucuAc();
    public void sogutucuKapat();
    public void sicaklikGoruntule();
}