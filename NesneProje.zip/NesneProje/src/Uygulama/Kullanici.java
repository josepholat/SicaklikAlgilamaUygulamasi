package Uygulama;

/**
 *
 * @author Ziroo
 */
public class Kullanici implements IObserver {
    private int kullaniciID;
    private String adi;
    private String soyadi;
    private String kullaniciadi;
    private String sifre;
    private boolean yetkiliMi;
    
    public Kullanici(String adi, String soyadi, String kullaniciadi, String sifre, boolean yetkiliMi) {
        this.adi = adi;
        this.soyadi = soyadi;
        this.kullaniciadi = kullaniciadi;
        this.sifre = sifre;
        this.yetkiliMi = yetkiliMi;
    }
    
    public int getKullaniciID() {
        return kullaniciID;
    }

    public void setKullaniciID(int kullaniciID) {
        this.kullaniciID = kullaniciID;
    }
  
    public String getAdi() {
        return adi;
    }

    public String getSoyadi() {
        return soyadi;
    }

    public String getKullaniciAdi() {
        return kullaniciadi;
    }

    public String getSifre() {
        return sifre;
    }

    public boolean isYetkiliMi() {
        return yetkiliMi;
    }

    @Override
    public void update(String mesaj) {
        System.out.println("Yoneticiye gelen mesaj-> "+ this.kullaniciadi + " " + mesaj);
    }

    
    
}
