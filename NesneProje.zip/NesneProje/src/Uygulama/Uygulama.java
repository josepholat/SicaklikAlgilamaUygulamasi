package Uygulama;

/**
 *
 * @author Ziroo
 */
public class Uygulama {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        AkilliCihaz akillicihaz = new AkilliCihaz();
        akillicihaz.baslat();
    }
    
}