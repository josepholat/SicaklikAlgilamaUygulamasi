package Uygulama;

import java.util.Scanner;

/**
 *
 * @author Ziroo
 */
public class MerkeziIslem implements IMerkeziIslem {

    private static IMerkeziIslem instance;

    private MerkeziIslem(){
        instance = null;
    }

    public static synchronized IMerkeziIslem getInstance(){
        if(instance == null)
            instance = new MerkeziIslem();
        return instance;
    }

    @Override
    public void sogutucuAc() {
        Eyleyici.getInstance().sogutucuAc();
    }

    @Override
    public void sogutucuKapat() {
        Eyleyici.getInstance().sogutucuKapat();
    }

    @Override
    public void sicaklikGoruntule() {
        int sicaklik = SicaklikAlgilayici.getInstance().sicaklikOku();
        System.out.println("Olculen Sicaklik Derecesi: " + sicaklik);
    }

}
