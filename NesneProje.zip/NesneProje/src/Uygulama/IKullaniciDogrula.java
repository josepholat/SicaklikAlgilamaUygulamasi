package Uygulama;

/**
 *
 * @author Ziroo
 */
public interface IKullaniciDogrula {
    Kullanici kullaniciyiGetir(String kullaniciadi,String sifre);
}