package Uygulama;

/**
 *
 * @author Ziroo
 */
public interface IEyleyici {
    public void sogutucuAc();
    public void sogutucuKapat();
}
