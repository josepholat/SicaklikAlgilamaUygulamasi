package Uygulama;

import java.util.Scanner;

/**
 *
 * @author Ziroo
 */
public class AkilliCihaz {

    private IAgArayuzu agArayuzu;
    private IKullaniciDogrula kulanicidogrulama;
    private Publisher publisher;
    private String durum = "kapali";

    public AkilliCihaz() {
        agArayuzu = AgArayuzu.getInstance();
        kulanicidogrulama = KullaniciDogrulaPostgreSQL.getInstance();
        publisher = new Publisher();
        durum = "bekleme";
    }

    public void baslat(){
        String mail;
        String sifre;
        Kullanici girisYapanKullanici;
        Scanner scanner=new Scanner(System.in);
        
         while(true){
            System.out.print("Kullanici Adinizi Giriniz:");
            mail=scanner.nextLine();
            System.out.print("Sifrenizi Giriniz:");
            sifre=scanner.nextLine();
            
            girisYapanKullanici = kulanicidogrulama.kullaniciyiGetir(mail, sifre);
            if(girisYapanKullanici == null)
            {
                System.out.println("Yanlis Kullanici Adi veye Sifre Girdiniz!!!");
                continue;
            }
            break; 
        }
        kullaniciBilgileriYazdir(girisYapanKullanici);
        publisher.attach(girisYapanKullanici);
        publisher.notify("sisteme giris yapti.");

        if(girisYapanKullanici.isYetkiliMi()) menuyuGetir();
        else System.out.println("Sıcaklık cihazını yönetme yetkiniz yok!");

 
    }
    
    private void kullaniciBilgileriYazdir(Kullanici kullanici){
        System.out.println("Hoşgeldiniz " + kullanici.getAdi() + " " + kullanici.getSoyadi());
    }
    
    private void cihazBilgileriYazdir(){
        System.out.println("Cihaz Çalışıyor...");
        System.out.println("Cihazin durumu: " + durum);
    }
    
    private void menuyuGetir(){
        
        while(true){
            cihazBilgileriYazdir();
            System.out.println("1 - Sıcaklığı Ölç");
            System.out.println("2 - Soğutucuyu Aç");
            System.out.println("3 - Sogutucuyu Kapat");
            System.out.println("4 - Çıkış");
        
            int secim;
        
            Scanner scanner = new Scanner(System.in);
            secim = scanner.nextInt();
        
            switch(secim){
                case 1:
                    AgArayuzu.getInstance().sicaklikGoruntule();
                    durum = "algılama";
                    break;
                
                case 2:
                    AgArayuzu.getInstance().sogutucuAc();
                    durum = "kontrol";
                    break;
                    
                case 3:
                    AgArayuzu.getInstance().sogutucuKapat();
                    durum = "bekleme";
                    break;
                
                case 4:
                    System.exit(0);
                    publisher.notify("sistemden cikis yapti.");
                    break;
                
                default:
                    System.out.println("Geçersiz bir giriş yaptınız!");
                    break;
            }
        }

    }
}
