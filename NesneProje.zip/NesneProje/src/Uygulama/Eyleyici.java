package Uygulama;

/**
 *
 * @author Ziroo
 */
public class Eyleyici implements IEyleyici {

    private static IEyleyici instance;

    private Eyleyici(){
        instance = null;
    }

    public static synchronized IEyleyici getInstance(){
        if(instance == null)
            instance = new Eyleyici();
        return instance;
    }

    @Override
    public void sogutucuAc() {
        System.out.println("soğutucu açıldı");
    }

    @Override
    public void sogutucuKapat() {
        System.out.println("soğutucu kapatıldı");
    }
}
